/**
 * @format
 */

import {AppRegistry} from 'react-native';
import App from './App';
import {name as appName} from './app.json';
import messaging from '@react-native-firebase/messaging';

messaging()
  .getInitialNotification()
  .then(async remoteMessage => {
    if (remoteMessage) {
      console.log(
        'getInitialNotification:' +
          'Notification caused app to open from quit state',
      );
      console.log(remoteMessage);
      alert(
        'getInitialNotification: Notification caused app to' +
          ' open from quit state',
      );
    }
  });

/**
 * When the user presses a notification displayed via FCM,
 * this listener will be called if the app has opened from
 * a background state. See `getInitialNotification` to see
 * how to watch for when a notification opens the app from
 * a quit state.
 */
messaging().onNotificationOpenedApp(async remoteMessage => {
  if (remoteMessage) {
    console.log(
      'onNotificationOpenedApp: ' +
        'Notification caused app to open from background state',
    );
    console.log(remoteMessage);
    alert(
      'onNotificationOpenedApp: Notification caused app to' +
        ' open from background state',
    );
  }
});

/**
 * Set a message handler function which is called when
 * the app is in the background or terminated. In Android,
 * a headless task is created, allowing you to access the
 * React Native environment to perform tasks such as updating
 * local storage, or sending a network request.
 */
messaging().setBackgroundMessageHandler(async remoteMessage => {
  console.log('Message handled in the background!', remoteMessage);
});

/**
 * When any FCM payload is received, the listener callback
 * is called with a `RemoteMessage`. Returns an unsubscribe
 * function to stop listening for new messages.
 */

/**
 * Apps can subscribe to a topic, which allows the FCM
 * server to send targeted messages to only those devices
 * subscribed to that topic.
 */

AppRegistry.registerComponent(appName, () => App);
