import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Transaction = () => {
  return (
    <View>
      <Text>Transaction</Text>
    </View>
  )
}

export default Transaction

const styles = StyleSheet.create({})