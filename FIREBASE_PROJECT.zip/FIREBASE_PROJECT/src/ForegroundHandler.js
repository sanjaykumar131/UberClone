import messaging from '@react-native-firebase/messaging';
import {useEffect} from 'react';
import PushNotification from 'react-native-push-notification';

export default ForegroundHandler = () => {
  useEffect(() => {
    messaging().setBackgroundMessageHandler(async remoteMessage => {
      console.log(
        'conditiio1',
        'getInitialNotification:' +
          'Notification caused app to open from quit state',
      );
      console.log('Message handled in the background!', remoteMessage);
    });

    messaging()
      .getInitialNotification()
      .then(async remoteMessage => {
        if (remoteMessage) {
          console.log(
            'conditiio2',
            'getInitialNotification:' +
              'Notification caused app to open from quit state',
          );
          console.log('tkttit========', remoteMessage);
          alert(
            'getInitialNotification: Notification caused app to' +
              ' open from quit state',
          );
        }
      });

    messaging().onNotificationOpenedApp(async remoteMessage => {
      console.log(
        'conditiio3',
        'getInitialNotification:' +
          'Notification caused app to open from quit state',
      );
      if (remoteMessage) {
        console.log(
          'onNotificationOpenedApp: ' +
            'Notification caused app to open from background state',
        );
        console.log(remoteMessage);
        alert(
          'onNotificationOpenedApp: Notification caused app to' +
            ' open from background state',
        );
      }
    });
    // const unSubscribe = messaging().onMessage(async remoteMessage => {
    //   console.log ('Notification in Foreground',remoteMessage);
    //   const {messageId, notification } = remoteMessage
    //   PushNotification.localNotification({
    //     channelId: 'CHANNEL-ID ',
    //     messageId: messageId,
    //     title: notification.title,
    //     body: notification.body,
    //     soundName: 'default',
    //     vibrate: true,
    //     playSound: true,
    //   })
    // });
    // return unSubscribe
  }, []);
  return null;
};
