import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Orders = () => {
  return (
    <View>
      <Text>Orders</Text>
    </View>
  )
}

export default Orders

const styles = StyleSheet.create({})