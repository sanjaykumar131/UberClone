import PushNotification from 'react-native-push-notification';

const showNotification = (title, message) => {
  PushNotification.localNotification({
    title: title,
    message: message,
  });
};

const handleScheduleNotification = (title, message) => {
  console.log('fdf====df=df=');
  PushNotification.localNotificationSchedule({
    title: title,
    date: new Date(Date.now() + 5 * 1000),
  });
};

const handleCancel = () => {
  PushNotification.cancelAllLocalNotifications();
};

export {showNotification, handleScheduleNotification, handleCancel};
